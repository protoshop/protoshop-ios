//
//  ModalCloseButton.h
//  popUpViewYu
//
//  Created by HongliYu on 14-2-11.
//  Copyright (c) 2014年 HongliYu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ModalCloseButton : UIButton

@end
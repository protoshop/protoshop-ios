//
//  UIView+Screenshot.h
//  PopupViewByhlyu
//
//  Created by hlyu on 13-9-16.
//  Copyright (c) 2013年 HongliYu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (Screenshot)
- (UIImage*)screenshot;
@end

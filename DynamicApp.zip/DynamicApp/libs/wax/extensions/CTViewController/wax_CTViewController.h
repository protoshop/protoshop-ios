#import <Foundation/Foundation.h>

#import "lua.h"

int luaopen_wax_CTViewController(lua_State *L);
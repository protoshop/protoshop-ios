//
//  CTButton
//  ToHell2iOS
//
//  Created by Anselz on 14-1-6.
//  Copyright (c) 2014年 kuolei. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CTActionModel.h"


@interface CTButton : UIButton

@property (nonatomic,strong) CTActionModel *actionModel;

@end

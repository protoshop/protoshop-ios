//
//  wax_CGAffine.h
//  EmpireState
//
//  Created by Corey Johnson on 10/6/09.
//  Copyright 2009 Probably Interactive. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "lua.h"

int luaopen_wax_CGTransform(lua_State *L);
#import <Foundation/Foundation.h>

#import "lua.h"

int luaopen_wax_CTView(lua_State *L);
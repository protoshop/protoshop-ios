//
//  CTLoginWebView.h
//  CtripSSOAuth
//
//  Created by Anselz on 14-3-6.
//  Copyright (c) 2014年 Anselz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CTLoginWebView : UIView

-(id)initWithDelegate:(id)delegate;
-(void)show;

@end

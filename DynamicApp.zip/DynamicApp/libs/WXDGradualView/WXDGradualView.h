//
//  gradualView.h
//  Protoshop
//
//  Created by HongliYu on 14-1-20.
//  Copyright (c) 2014年 kuolei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WXDGradualView : UIView

@end

//
//  WXDLoginViewController.h
//  ToHell2iOS
//
//  Created by HongliYu on 14-1-15.
//  Copyright (c) 2014年 kuolei. All rights reserved.
//
//  Protoshop 登录页面控制器
//  归属人：虞鸿礼
//  修改时间：2014年5月13日

#import <UIKit/UIKit.h>
#import "WXDRequestCommand.h"

@interface WXDLoginViewController : WXDBaseViewController

@end
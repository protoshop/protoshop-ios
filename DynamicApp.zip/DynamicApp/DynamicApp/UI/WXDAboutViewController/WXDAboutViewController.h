//
//  WXDAboutViewController.h
//  Protoshop
//
//  Created by HongliYu on 14-5-27.
//  Copyright (c) 2014年 kuolei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WXDAboutViewController : UIViewController

@end

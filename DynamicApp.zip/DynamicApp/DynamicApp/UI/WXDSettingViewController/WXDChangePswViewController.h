//
//  WXDChangePswViewController.h
//  Protoshop
//
//  Created by HongliYu on 14-2-17.
//  Copyright (c) 2014年 kuolei. All rights reserved.
//
//  Protoshop 密码修改页面控制器
//  归属人：虞鸿礼
//  修改时间：2014年5月14日

#import <UIKit/UIKit.h>
#import "WXDRequestCommand.h"

@interface WXDChangePswViewController : WXDBaseViewController

@end
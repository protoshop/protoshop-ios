//
//  WXDSettingViewController.h
//  Protoshop
//
//  Created by HongliYu on 14-1-24.
//  Copyright (c) 2014年 kuolei. All rights reserved.
//
//  Protoshop 设置页面控制器
//  归属人：虞鸿礼
//  修改时间：2014年5月14日

#import <UIKit/UIKit.h>
#import "WXDAppDelegate.h"

@interface WXDSettingViewController : WXDBaseViewController

@end
